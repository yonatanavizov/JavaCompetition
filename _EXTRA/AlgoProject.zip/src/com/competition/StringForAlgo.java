package com.competition;

public class StringForAlgo
{
	public String text;
	public int length;
	public int hash;
	
	public StringForAlgo(String str)
	{
		this.text = str;
		length = str.length();
	}
}